<?php
setlocale(LC_TIME,"spanish.UTF-8");
$fecha = strftime("%A %d de %B del %Y");
echo $fecha;
?>