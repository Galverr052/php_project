<footer class="mt-10 py-6 text-center text-gray-500 border-t">
    <p>&copy; <?= date("Y") ?> - Mi Blog Personal con PHP</p>
</footer>
